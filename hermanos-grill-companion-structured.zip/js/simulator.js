/* ==========================================================
   Hermanos Grill Companion
   simulator.js

   Simuleert Bluetooth thermometer data
   ========================================================== */


function startSimulator(){


    setInterval(()=>{


        updateTemperatures();


        updateBattery();


        render();


    },2000);


}





function updateTemperatures(){


    const dome = appState.probes.find(
        p => p.type === "dome"
    );


    const meat = appState.probes.find(
        p => p.type === "meat"
    );



    if(!dome || !meat) return;



    /*
        Dome temperatuur
        beweegt naar cook target
    */


    if(appState.cook.active){


        const target =
        appState.cook.domeTarget;



        if(dome.temperature < target){

            dome.temperature += random(1,4);

        }


        if(dome.temperature > target){

            dome.temperature -= random(1,3);

        }


    }



    /*
        Vlees temperatuur
        stijgt langzaam
    */


    if(appState.cook.active){


        const meatTarget =
        appState.cook.meatTarget;



        if(
            meatTarget &&
            meat.temperature < meatTarget
        ){

            meat.temperature += 0.2;

        }


    }


}






function updateBattery(){


    if(
        appState.bluetooth.battery > 0
    ){

        appState.bluetooth.battery -= 0.01;

    }


}






function random(min,max){


    return Math.random() *
    (max-min)+min;


}






// starten zodra bestand geladen is

startSimulator();