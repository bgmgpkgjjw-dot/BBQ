/* ==========================================================
   Hermanos Grill Companion
   dashboard.js

   Dashboard scherm
   ========================================================== */


function dashboardView(){


    const dome = appState.probes.find(
        p => p.type === "dome"
    );


    const meat = appState.probes.find(
        p => p.type === "meat"
    );


    return `


    <div class="status">

        ${appState.bluetooth.connected ? "🟢" : "🔴"}

        ${appState.bluetooth.device}

        ·

        Batterij ${appState.bluetooth.battery}%

    </div>




    <div class="gauge">


        <div>


            <div class="temp">

                ${Math.round(dome.temperature)}°

            </div>


            <div class="label">

                Dome

            </div>


        </div>


    </div>





    <div class="card">


        <h3>

            Vleesprobe

        </h3>


        <div class="temp" style="font-size:42px">

            ${Math.round(meat.temperature)}°

        </div>


        <p style="color:var(--muted); text-align:center">

            Target:

            ${appState.cook.meatTarget || "—"}°C

        </p>


    </div>





    <div class="card">


        <h3>

            Actieve cook

        </h3>


        ${
            appState.cook.active

            ?

            `

            <h2>

                ${appState.cook.name}

            </h2>


            <p>

                Dome:

                ${appState.cook.domeTarget}°C

            </p>


            <p>

                Kern:

                ${appState.cook.meatTarget || "—"}°C

            </p>


            `


            :


            `

            <p>

                Geen actieve cook

            </p>


            `

        }


    </div>





    <div class="card">


        <h3>

            Sondes

        </h3>


        ${


            appState.probes

            .filter(p => p.active)

            .map(p => `


                <div style="
                display:flex;
                justify-content:space-between;
                margin-bottom:10px;
                ">


                    <span>

                        ${p.name}

                    </span>


                    <strong>

                        ${Math.round(p.temperature)}°C

                    </strong>


                </div>


            `)

            .join("")


        }


    </div>





    <button

        class="button"

        onclick="navigate('recipes')"

    >

        🍖 Kies een recept


    </button>


    `;


}
